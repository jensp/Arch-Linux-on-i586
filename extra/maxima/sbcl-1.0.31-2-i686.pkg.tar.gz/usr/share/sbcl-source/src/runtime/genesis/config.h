/*
 * This is a machine-generated file. Please do not edit it by hand.
 * (As of sbcl-0.8.14, it came from WRITE-CONFIG-H in genesis.lisp.)
 *
 * This file contains low-level information about the
 * internals of a particular version and configuration
 * of SBCL. It is used by the C compiler to create a runtime
 * support environment, an executable program in the host
 * operating system's native format, which can then be used to
 * load and run 'core' files, which are basically programs
 * in SBCL's own format.
 */
#ifndef SBCL_GENESIS_CONFIG
#define SBCL_GENESIS_CONFIG 1
#define LISP_FEATURE_ALIEN_CALLBACKS
#define LISP_FEATURE_ANSI_CL
#define LISP_FEATURE_COMMON_LISP
#define LISP_FEATURE_COMPARE_AND_SWAP_VOPS
#define LISP_FEATURE_CYCLE_COUNTER
#define LISP_FEATURE_C_STACK_IS_CONTROL_STACK
#define LISP_FEATURE_ELF
#define LISP_FEATURE_GENCGC
#define LISP_FEATURE_IEEE_FLOATING_POINT
#define LISP_FEATURE_INLINE_CONSTANTS
#define LISP_FEATURE_LINKAGE_TABLE
#define LISP_FEATURE_LINUX
#define LISP_FEATURE_OS_PROVIDES_DLOPEN
#define LISP_FEATURE_OS_PROVIDES_PUTWC
#define LISP_FEATURE_OS_PROVIDES_SUSECONDS_T
#define LISP_FEATURE_RAW_INSTANCE_INIT_VOPS
#define LISP_FEATURE_SBCL
#define LISP_FEATURE_SB_DOC
#define LISP_FEATURE_SB_EVAL
#define LISP_FEATURE_SB_LDB
#define LISP_FEATURE_SB_PACKAGE_LOCKS
#define LISP_FEATURE_SB_SOURCE_LOCATIONS
#define LISP_FEATURE_SB_TEST
#define LISP_FEATURE_SB_THREAD
#define LISP_FEATURE_SB_UNICODE
#define LISP_FEATURE_STACK_ALLOCATABLE_CLOSURES
#define LISP_FEATURE_STACK_ALLOCATABLE_FIXED_OBJECTS
#define LISP_FEATURE_STACK_ALLOCATABLE_LISTS
#define LISP_FEATURE_STACK_ALLOCATABLE_VECTORS
#define LISP_FEATURE_STACK_GROWS_DOWNWARD_NOT_UPWARD
#define LISP_FEATURE_UNIX
#define LISP_FEATURE_UNWIND_TO_FRAME_AND_CALL_VOP
#define LISP_FEATURE_X86

#define SBCL_CORE_VERSION_INTEGER 4
#define SBCL_VERSION_STRING "1.0.31"
#define CORE_MAGIC 0x5342434C
#ifndef LANGUAGE_ASSEMBLY

#define LISPOBJ(x) ((lispobj)x)

#else /* LANGUAGE_ASSEMBLY */

#define LISPOBJ(thing) thing

#endif /* LANGUAGE_ASSEMBLY */


#endif /* SBCL_GENESIS_CONFIG */
